-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2024 at 05:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_654230044`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_football_tickets`
--

CREATE TABLE `tb_football_tickets` (
  `ticket_id` int(11) UNSIGNED NOT NULL,
  `football_club` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `uploadBy` varchar(100) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_football_tickets`
--

INSERT INTO `tb_football_tickets` (`ticket_id`, `football_club`, `price`, `uploadBy`, `reg_date`) VALUES
(0, 'ลิเวอร์พูล vs แมนยู ไนเต็ด', 5000, 'First', '2024-08-01 15:02:44'),
(0, 'ลิเวอร์พูล vs นิวคาสเซิ่ล', 2480, 'Natee', '2024-08-01 15:03:36'),
(0, 'ลิเวอร์พูล vs เอฟเวอร์ตัน', 3500, 'Kloop', '2024-08-01 15:04:20'),
(0, 'ลิเวอร์พูล vs เรอัล มาดริด (Uf', 15950, 'Mo Salah', '2024-08-01 15:05:24'),
(0, 'ลิเวอร์พูล vs เรอัล มาดริด (Uf', 15950, 'Mo Salah', '2024-08-01 15:06:02'),
(0, 'ลิเวอร์พูล vs เรอัล มาดริด (Uf', 15950, 'Mo Salah', '2024-08-01 15:11:44');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
